# Airport Services Management System

The **Airport Services Management System** is a robust backend-only REST API system designed to centralize and simplify the management of flights, passenger records, staff directory, and ticketing bookings. 

This project is built using **Node.js**, **Express**, **TypeScript**, and **MongoDB** (via Mongoose). It comes equipped with interactive **Swagger API Documentation** and an exportable **Postman Collection** for easy API testing.

---

## Developer Information
- **Developer Name**: Pranay Sharma
- **Registration Number**: 24BAI10618
- **University**: VIT Bhopal University
- **Branch**: Computer Science Engineering
- **Year**: 2026-2027

---

## Key Features
- **Flight Management (CRUD)**: Schedule and search flights by origin, destination, and departure date.
- **Passenger Management (CRUD)**: Manage passenger profiles including contact information and passport records.
- **Staff Management (CRUD)**: Track airport staff schedules, salaries, and specific roles (Pilots, Flight Attendants, Ground Staff, Admin).
- **Seat Booking & Reservation Engine**:
  - Validates flight existence and seats availability before finalizing ticket generation.
  - Automatically generates a unique 6-character alphanumeric booking reference (`BK-XXXXXX`).
  - **Concurrency Control**: Atomically decrements available seats during reservations to prevent double-booking.
  - **Cancellations & Refunds**: Restores seat availability on flight cancellations.
- **Interactive Documentation**: Access OpenAPI 3.0 documentation using Swagger UI.
- **Postman Integration**: Immediate import of all configured endpoints using the included collection file.

---

## Technology Stack
- **Runtime**: Node.js (v24.x LTS recommended)
- **Framework**: Express (with TypeScript)
- **Database**: MongoDB (Object Data Modeling via Mongoose)
- **Documentation**: Swagger UI Express & Swagger JSDoc
- **API Testing**: Postman Collection (v2.1)

---

## Project Structure
```text
├── src/
│   ├── config/
│   │   └── db.ts             # MongoDB Connection Setup
│   ├── models/
│   │   ├── flight.model.ts   # Flight Mongoose Schema & Interface
│   │   ├── passenger.model.ts# Passenger Mongoose Schema & Interface
│   │   ├── staff.model.ts    # Staff Mongoose Schema & Interface
│   │   └── booking.model.ts  # Booking Mongoose Schema & Interface
│   ├── controllers/
│   │   ├── flight.controller.ts
│   │   ├── passenger.controller.ts
│   │   ├── staff.controller.ts
│   │   └── booking.controller.ts
│   ├── routes/
│   │   ├── flight.routes.ts   # Flight endpoints with Swagger documentation tags
│   │   ├── passenger.routes.ts# Passenger endpoints with Swagger documentation tags
│   │   ├── staff.routes.ts    # Staff endpoints with Swagger documentation tags
│   │   └── booking.routes.ts  # Booking endpoints with Swagger documentation tags
│   ├── app.ts                # Express app setup and middleware configuration
│   ├── server.ts             # Server startup entry file
│   └── swagger.ts            # Swagger Configuration setup
├── tsconfig.json             # TypeScript Compiler config
├── package.json              # Project script tasks and dependency manager
├── .env                      # Local environment configurations (ignored from Git)
└── postman_collection.json   # Exported Postman collection for API test automation
```

---

## Getting Started

### 1. Prerequisites
- **Node.js**: Install Node.js LTS (includes `npm`).
- **MongoDB**: Ensure MongoDB Community Server is installed locally and running on port `27017` (or provide a cloud MongoDB Atlas URI).

### 2. Installation
Clone/extract the project directory and open a terminal inside it. Then run:
```bash
npm install
```

### 3. Environment Variable Config
Create a file named `.env` in the root directory and add the following keys:
```env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/airport-db
```

### 4. Running the Project

#### Development Mode (With hot-reloading)
Runs the server using `ts-node-dev`. The server automatically restarts on source code changes.
```bash
npm run dev
```

#### Production Mode (Compile & Run)
Compiles TypeScript code into standard JavaScript in the `/dist` directory and boots the compiled code:
```bash
npm run build
npm start
```

Once started, the server will output:
```text
Successfully connected to MongoDB.
Server is running in development mode on port 5000
API base path: http://localhost:5000
Swagger docs available at http://localhost:5000/api-docs
```

---

## API Testing

### 1. Swagger UI (Interactive Browser Console)
1. Open your web browser.
2. Navigate to: **`http://localhost:5000/api-docs`**
3. You will see a complete, interactive documentation dashboard. You can click on individual endpoints, view schemas, click **"Try it out"**, fill in data parameters, and run direct API requests.

### 2. Postman Collection
1. Open Postman.
2. Click **Import** in the top left.
3. Select the file **`postman_collection.json`** from this project directory.
4. Once imported, you will see the folder structure for **Airport Services Management System**.
5. Set your variables or update the Collection Variables in Postman for easy parameterized testing:
   - `baseUrl`: `http://localhost:5000`
   - `flightId`, `passengerId`, `staffId`, `bookingId`: fill these with actual database ObjectId strings generated when creating entries.
