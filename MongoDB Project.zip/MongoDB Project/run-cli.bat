@echo off
echo Starting Airport Services Management System CLI...
"C:\Users\priya\AppData\Local\ms-playwright-go\1.57.0\node.exe" dist/cli.js
pause
