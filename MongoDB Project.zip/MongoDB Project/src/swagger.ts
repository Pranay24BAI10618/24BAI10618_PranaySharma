import swaggerJSDoc from 'swagger-jsdoc';
import swaggerUi from 'swagger-ui-express';
import { Express } from 'express';

const options: swaggerJSDoc.Options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'Airport Services Management System API',
      version: '1.0.0',
      description: `
This API simplifies the management of airport data by keeping track of flights, passenger details, staff information, and booking records.
It provides easy access to important information and supports smooth airport operations through centralized management.

### Developer Info:
- **Name**: Pranay Sharma
- **Reg No**: 24BAI10618
- **University**: VIT Bhopal University
- **Branch**: Computer Science Engineering
- **Year**: 2026-2027
      `,
      contact: {
        name: 'Pranay Sharma',
        email: 'pranay.sharma2024@vitbhopal.ac.in', // standard format
      },
    },
    servers: [
      {
        url: 'http://localhost:5000',
        description: 'Development Server',
      },
    ],
  },
  // Paths to APIs we want to document
  apis: ['./src/routes/*.ts', './dist/routes/*.js', './src/routes/*.js'],
};

const swaggerSpec = swaggerJSDoc(options);

export const setupSwagger = (app: Express): void => {
  app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));
  console.log('Swagger docs available at http://localhost:5000/api-docs');
};
