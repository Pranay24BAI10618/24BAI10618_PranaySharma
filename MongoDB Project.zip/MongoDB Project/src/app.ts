import express from 'express';
import cors from 'cors';
import { setupSwagger } from './swagger';
import flightRouter from './routes/flight.routes';
import passengerRouter from './routes/passenger.routes';
import staffRouter from './routes/staff.routes';
import bookingRouter from './routes/booking.routes';

const app = express();

app.use(cors());
app.use(express.json());

// Base API Routes
app.use('/api/flights', flightRouter);
app.use('/api/passengers', passengerRouter);
app.use('/api/staff', staffRouter);
app.use('/api/bookings', bookingRouter);

// Home route
app.get('/', (_req, res) => {
  res.json({
    message: 'Welcome to the Airport Services Management System API',
    system: 'Airport Services Management System',
    developer: {
      name: 'Pranay Sharma',
      regNo: '24BAI10618',
      university: 'VIT Bhopal University',
      branch: 'Computer Science Engineering',
      year: '2026-2027'
    },
    documentation: '/api-docs'
  });
});

// Setup Swagger
setupSwagger(app);

export default app;
