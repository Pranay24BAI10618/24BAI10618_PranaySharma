import mongoose from 'mongoose';
import dotenv from 'dotenv';
import { connectDB } from './config/db';
import Flight from './models/flight.model';
import Passenger from './models/passenger.model';
import Staff from './models/staff.model';
import Booking from './models/booking.model';

dotenv.config();

const flightsData = [
  {
    flightNumber: 'AI-101',
    airline: 'Air India',
    origin: 'DEL',
    destination: 'BOM',
    departureTime: new Date('2026-06-17T10:00:00Z'),
    arrivalTime: new Date('2026-06-17T12:15:00Z'),
    status: 'Scheduled',
    price: 150.00,
    capacity: 180,
    availableSeats: 178,
    gate: 'Gate A12'
  },
  {
    flightNumber: 'EK-503',
    airline: 'Emirates',
    origin: 'BOM',
    destination: 'DXB',
    departureTime: new Date('2026-06-16T22:30:00Z'),
    arrivalTime: new Date('2026-06-17T00:15:00Z'),
    status: 'Delayed',
    price: 350.00,
    capacity: 250,
    availableSeats: 250,
    gate: 'Gate B3'
  },
  {
    flightNumber: 'LH-761',
    airline: 'Lufthansa',
    origin: 'DEL',
    destination: 'FRA',
    departureTime: new Date('2026-06-16T18:00:00Z'),
    arrivalTime: new Date('2026-06-17T02:00:00Z'),
    status: 'Departed',
    price: 600.00,
    capacity: 300,
    availableSeats: 300,
    gate: 'Gate C5'
  },
  {
    flightNumber: 'SG-205',
    airline: 'SpiceJet',
    origin: 'DEL',
    destination: 'MAA',
    departureTime: new Date('2026-06-17T00:00:00Z'),
    arrivalTime: new Date('2026-06-17T02:45:00Z'),
    status: 'Cancelled',
    price: 90.00,
    capacity: 150,
    availableSeats: 150,
    gate: 'Gate A4'
  },
  {
    flightNumber: 'SQ-406',
    airline: 'Singapore Airlines',
    origin: 'BOM',
    destination: 'SIN',
    departureTime: new Date('2026-06-17T04:00:00Z'),
    arrivalTime: new Date('2026-06-17T09:30:00Z'),
    status: 'Scheduled',
    price: 400.00,
    capacity: 280,
    availableSeats: 279,
    gate: 'Gate A10'
  },
  {
    flightNumber: 'BA-142',
    airline: 'British Airways',
    origin: 'DEL',
    destination: 'LHR',
    departureTime: new Date('2026-06-18T06:15:00Z'),
    arrivalTime: new Date('2026-06-18T11:45:00Z'),
    status: 'Scheduled',
    price: 750.00,
    capacity: 320,
    availableSeats: 320,
    gate: 'Gate B1'
  },
  {
    flightNumber: 'UA-901',
    airline: 'United Airlines',
    origin: 'BOM',
    destination: 'EWR',
    departureTime: new Date('2026-06-17T08:00:00Z'),
    arrivalTime: new Date('2026-06-17T22:30:00Z'),
    status: 'Scheduled',
    price: 950.00,
    capacity: 350,
    availableSeats: 350,
    gate: 'Gate C2'
  },
  {
    flightNumber: 'AA-234',
    airline: 'American Airlines',
    origin: 'DEL',
    destination: 'JFK',
    departureTime: new Date('2026-06-15T22:00:00Z'),
    arrivalTime: new Date('2026-06-16T11:30:00Z'),
    status: 'Landed',
    price: 1100.00,
    capacity: 310,
    availableSeats: 310,
    gate: 'Gate A8'
  }
];

const passengersData = [
  {
    passportNumber: 'Z1234567',
    firstName: 'Pranay',
    lastName: 'Sharma',
    email: 'pranay.sharma@example.com',
    phone: '+919876543210',
    gender: 'Male',
    dateOfBirth: new Date('2004-05-15')
  },
  {
    passportNumber: 'A9876543',
    firstName: 'Aditya',
    lastName: 'Verma',
    email: 'aditya.verma@example.com',
    phone: '+919123456789',
    gender: 'Male',
    dateOfBirth: new Date('2003-08-20')
  },
  {
    passportNumber: 'B1122334',
    firstName: 'Ananya',
    lastName: 'Rao',
    email: 'ananya.rao@example.com',
    phone: '+918877665544',
    gender: 'Female',
    dateOfBirth: new Date('2005-12-10')
  }
];
const staffData = [
  {
    staffId: 'STF-2004',
    firstName: 'Amit',
    lastName: 'Patel',
    email: 'amit.patel@airport.com',
    phone: '+919999988888',
    role: 'Pilot',
    department: 'Operations',
    salary: 8500
  },
  {
    staffId: 'STF-3001',
    firstName: 'Priya',
    lastName: 'Sharma',
    email: 'priya.sharma@airport.com',
    phone: '+918888877777',
    role: 'Flight Attendant',
    department: 'Cabin Crew',
    salary: 4200
  },
  {
    staffId: 'STF-4002',
    firstName: 'Rohan',
    lastName: 'Deshmukh',
    email: 'rohan.deshmukh@airport.com',
    phone: '+917777766666',
    role: 'Ground Staff',
    department: 'Logistics',
    salary: 3500
  }
];
const seedDatabase = async () => {
  try {
    await connectDB();

    // Clear existing data
    await Flight.deleteMany({});
    await Passenger.deleteMany({});
    await Staff.deleteMany({});
    await Booking.deleteMany({});

    console.log('Cleared existing database entries.');

    // Seed Flights
    const createdFlights = await Flight.insertMany(flightsData);
    console.log(`Successfully seeded ${createdFlights.length} Flights.`);

    // Seed Passengers
    const createdPassengers = await Passenger.insertMany(passengersData);
    console.log(`Successfully seeded ${createdPassengers.length} Passengers.`);

    // Seed Staff
    const createdStaff = await Staff.insertMany(staffData);
    console.log(`Successfully seeded ${createdStaff.length} Staff members.`);

    // Seed Bookings
    const bookingsData = [
      {
        bookingReference: 'BK-T8H4G2',
        flight: createdFlights[0]._id, // AI-101
        passenger: createdPassengers[0]._id, // Pranay Sharma
        seatNumber: '12A',
        class: 'Economy',
        pricePaid: 150.00,
        status: 'Confirmed'
      },
      {
        bookingReference: 'BK-Y8A3P9',
        flight: createdFlights[4]._id, // SQ-406
        passenger: createdPassengers[1]._id, // Aditya Verma
        seatNumber: '3C',
        class: 'Business',
        pricePaid: 400.00,
        status: 'Confirmed'
      }
    ];

    const createdBookings = await Booking.insertMany(bookingsData);
    console.log(`Successfully seeded ${createdBookings.length} Bookings.`);

    console.log('\n\x1b[32mDatabase population complete! All mock records successfully seeded.\x1b[0m');
    await mongoose.connection.close();
    process.exit(0);
  } catch (error) {
    console.error('Error seeding database:', error);
    process.exit(1);
  }
};

seedDatabase();
