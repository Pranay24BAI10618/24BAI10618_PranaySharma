import app from './app';
import { connectDB } from './config/db';
import dotenv from 'dotenv';

dotenv.config();

const PORT = process.env.PORT || 5000;

const startServer = async () => {
  // Connect to Database
  await connectDB();

  // Start Express Server
  app.listen(PORT, () => {
    console.log(`Server is running in development mode on port ${PORT}`);
    console.log(`API base path: http://localhost:${PORT}`);
  });
};

startServer();
