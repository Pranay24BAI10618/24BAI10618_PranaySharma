import { Router } from 'express';
import {
  createBooking,
  getAllBookings,
  getBookingById,
  cancelBooking,
  deleteBooking
} from '../controllers/booking.controller';

const router = Router();

/**
 * @swagger
 * components:
 *   schemas:
 *     BookingRequest:
 *       type: object
 *       required:
 *         - flightId
 *         - passengerId
 *         - seatNumber
 *       properties:
 *         flightId:
 *           type: string
 *           description: The MongoDB ObjectId of the flight
 *         passengerId:
 *           type: string
 *           description: The MongoDB ObjectId of the passenger
 *         seatNumber:
 *           type: string
 *           description: Designated seat code (e.g., 12A)
 *         class:
 *           type: string
 *           enum: [Economy, Business, First]
 *           default: Economy
 *           description: Booking seat class
 *         pricePaid:
 *           type: number
 *           description: The price paid. If omitted, defaults to the flight's original price.
 *       example:
 *         flightId: 60d21b4667d0d8992e610c85
 *         passengerId: 60d21b4667d0d8992e610c86
 *         seatNumber: 15C
 *         class: Economy
 * 
 *     BookingResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           description: Booking ID
 *         bookingReference:
 *           type: string
 *           description: Automatically generated unique 6-character alphanumeric reference (e.g. BK-Y7H29A)
 *         flight:
 *           $ref: '#/components/schemas/Flight'
 *         passenger:
 *           $ref: '#/components/schemas/Passenger'
 *         seatNumber:
 *           type: string
 *         bookingDate:
 *           type: string
 *           format: date-time
 *         class:
 *           type: string
 *         status:
 *           type: string
 *           enum: [Confirmed, Cancelled]
 *         pricePaid:
 *           type: number
 */

/**
 * @swagger
 * tags:
 *   name: Bookings
 *   description: Flight booking and ticket management APIs
 */

/**
 * @swagger
 * /api/bookings:
 *   post:
 *     summary: Reserve a seat and book a flight
 *     description: Validates flight capacity, atomically decrements available seats, verifies passenger details, and generates a ticket.
 *     tags: [Bookings]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/BookingRequest'
 *     responses:
 *       201:
 *         description: Ticket successfully booked
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/BookingResponse'
 *       400:
 *         description: No seats available / invalid request parameters
 *       404:
 *         description: Flight or Passenger not found
 */
router.post('/', createBooking);

/**
 * @swagger
 * /api/bookings:
 *   get:
 *     summary: Retrieve bookings
 *     tags: [Bookings]
 *     parameters:
 *       - in: query
 *         name: passengerId
 *         schema:
 *           type: string
 *         description: Filter bookings by passenger database ID
 *       - in: query
 *         name: flightId
 *         schema:
 *           type: string
 *         description: Filter bookings by flight database ID
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [Confirmed, Cancelled]
 *         description: Filter bookings by status
 *     responses:
 *       200:
 *         description: List of bookings matching filters
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/BookingResponse'
 *       500:
 *         description: Internal server error
 */
router.get('/', getAllBookings);

/**
 * @swagger
 * /api/bookings/{id}:
 *   get:
 *     summary: Get booking details by ID
 *     tags: [Bookings]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The booking ID
 *     responses:
 *       200:
 *         description: Detailed booking information with populated relations
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/BookingResponse'
 *       404:
 *         description: Booking not found
 *       500:
 *         description: Internal server error
 */
router.get('/:id', getBookingById);

/**
 * @swagger
 * /api/bookings/{id}/cancel:
 *   post:
 *     summary: Cancel a flight booking
 *     description: Cancels the booking and releases the reserved seat, incrementing the flight's available seat count.
 *     tags: [Bookings]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The booking ID
 *     responses:
 *       200:
 *         description: Booking successfully cancelled and seat released
 *       400:
 *         description: Booking already cancelled or invalid request
 *       404:
 *         description: Booking not found
 */
router.post('/:id/cancel', cancelBooking);

/**
 * @swagger
 * /api/bookings/{id}:
 *   delete:
 *     summary: Delete booking record
 *     description: Permanently deletes the booking record. If the booking was confirmed, restores the flight's seat availability.
 *     tags: [Bookings]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The booking ID
 *     responses:
 *       200:
 *         description: Booking record deleted
 *       404:
 *         description: Booking not found
 */
router.delete('/:id', deleteBooking);

export default router;
