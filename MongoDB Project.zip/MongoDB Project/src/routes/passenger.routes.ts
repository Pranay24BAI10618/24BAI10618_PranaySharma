import { Router } from 'express';
import {
  createPassenger,
  getAllPassengers,
  getPassengerById,
  updatePassenger,
  deletePassenger
} from '../controllers/passenger.controller';

const router = Router();

/**
 * @swagger
 * components:
 *   schemas:
 *     Passenger:
 *       type: object
 *       required:
 *         - passportNumber
 *         - firstName
 *         - lastName
 *         - email
 *         - phone
 *         - gender
 *         - dateOfBirth
 *       properties:
 *         id:
 *           type: string
 *           description: The auto-generated ID of the passenger
 *         passportNumber:
 *           type: string
 *           description: Unique passport number of the passenger
 *         firstName:
 *           type: string
 *           description: First name of the passenger
 *         lastName:
 *           type: string
 *           description: Last name of the passenger
 *         email:
 *           type: string
 *           description: Email address (unique)
 *         phone:
 *           type: string
 *           description: Phone contact number
 *         gender:
 *           type: string
 *           enum: [Male, Female, Other]
 *           description: Passenger's gender
 *         dateOfBirth:
 *           type: string
 *           format: date
 *           description: Date of birth (YYYY-MM-DD)
 *       example:
 *         passportNumber: Z1234567
 *         firstName: Pranay
 *         lastName: Sharma
 *         email: pranay.sharma@example.com
 *         phone: '+919876543210'
 *         gender: Male
 *         dateOfBirth: '2004-05-15'
 */

/**
 * @swagger
 * tags:
 *   name: Passengers
 *   description: Passenger management APIs
 */

/**
 * @swagger
 * /api/passengers:
 *   post:
 *     summary: Register a new passenger
 *     tags: [Passengers]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Passenger'
 *     responses:
 *       201:
 *         description: The passenger was successfully created
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Passenger'
 *       400:
 *         description: Email or passport number already exists / validation failure
 */
router.post('/', createPassenger);

/**
 * @swagger
 * /api/passengers:
 *   get:
 *     summary: Retrieve all registered passengers
 *     tags: [Passengers]
 *     parameters:
 *       - in: query
 *         name: passportNumber
 *         schema:
 *           type: string
 *         description: Filter passengers by passport number
 *       - in: query
 *         name: email
 *         schema:
 *           type: string
 *         description: Filter passengers by email address
 *     responses:
 *       200:
 *         description: List of all passengers
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Passenger'
 *       500:
 *         description: Internal server error
 */
router.get('/', getAllPassengers);

/**
 * @swagger
 * /api/passengers/{id}:
 *   get:
 *     summary: Get passenger by ID
 *     tags: [Passengers]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The passenger ID
 *     responses:
 *       200:
 *         description: Passenger details by ID
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Passenger'
 *       404:
 *         description: Passenger not found
 *       500:
 *         description: Internal server error
 */
router.get('/:id', getPassengerById);

/**
 * @swagger
 * /api/passengers/{id}:
 *   put:
 *     summary: Update passenger details
 *     tags: [Passengers]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The passenger ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Passenger'
 *     responses:
 *       200:
 *         description: Passenger details successfully updated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Passenger'
 *       400:
 *         description: Invalid fields or validation error
 *       404:
 *         description: Passenger not found
 */
router.put('/:id', updatePassenger);

/**
 * @swagger
 * /api/passengers/{id}:
 *   delete:
 *     summary: Delete a passenger
 *     tags: [Passengers]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The passenger ID
 *     responses:
 *       200:
 *         description: Passenger deleted successfully
 *       404:
 *         description: Passenger not found
 *       500:
 *         description: Internal server error
 */
router.delete('/:id', deletePassenger);

export default router;
