import { Router } from 'express';
import {
  createFlight,
  getAllFlights,
  getFlightById,
  updateFlight,
  deleteFlight,
  searchFlights
} from '../controllers/flight.controller';

const router = Router();

/**
 * @swagger
 * components:
 *   schemas:
 *     Flight:
 *       type: object
 *       required:
 *         - flightNumber
 *         - airline
 *         - origin
 *         - destination
 *         - departureTime
 *         - arrivalTime
 *         - price
 *         - capacity
 *       properties:
 *         id:
 *           type: string
 *           description: The auto-generated ID of the flight
 *         flightNumber:
 *           type: string
 *           description: Unique code of the flight (e.g., AI-101)
 *         airline:
 *           type: string
 *           description: Airline brand name
 *         origin:
 *           type: string
 *           description: Departure airport/city code (e.g., DEL)
 *         destination:
 *           type: string
 *           description: Arrival airport/city code (e.g., BOM)
 *         departureTime:
 *           type: string
 *           format: date-time
 *           description: Departure date and time
 *         arrivalTime:
 *           type: string
 *           format: date-time
 *           description: Arrival date and time
 *         status:
 *           type: string
 *           enum: [Scheduled, Delayed, Boarding, Departed, Landed, Cancelled]
 *           default: Scheduled
 *           description: Current status of the flight
 *         price:
 *           type: number
 *           description: Price of a ticket
 *         capacity:
 *           type: integer
 *           description: Maximum capacity of passengers
 *         availableSeats:
 *           type: integer
 *           description: Remaining empty seats (defaults to capacity)
 *         gate:
 *           type: string
 *           description: Designated boarding gate (defaults to Gate TBD)
 *       example:
 *         flightNumber: AI-101
 *         airline: Air India
 *         origin: DEL
 *         destination: BOM
 *         departureTime: '2026-07-20T10:00:00.000Z'
 *         arrivalTime: '2026-07-20T12:30:00.000Z'
 *         status: Scheduled
 *         price: 150.50
 *         capacity: 180
 *         gate: Gate A12
 */

/**
 * @swagger
 * tags:
 *   name: Flights
 *   description: Flight management APIs
 */

/**
 * @swagger
 * /api/flights:
 *   post:
 *     summary: Create a new flight
 *     tags: [Flights]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Flight'
 *     responses:
 *       201:
 *         description: The flight was successfully created
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Flight'
 *       400:
 *         description: Invalid input or database validation failed
 */
router.post('/', createFlight);

/**
 * @swagger
 * /api/flights:
 *   get:
 *     summary: Retrieve a list of all flights
 *     tags: [Flights]
 *     parameters:
 *       - in: query
 *         name: origin
 *         schema:
 *           type: string
 *         description: Filter flights by origin city/airport
 *       - in: query
 *         name: destination
 *         schema:
 *           type: string
 *         description: Filter flights by destination city/airport
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [Scheduled, Delayed, Boarding, Departed, Landed, Cancelled]
 *         description: Filter flights by current status
 *     responses:
 *       200:
 *         description: List of all flights
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Flight'
 *       500:
 *         description: Internal server error
 */
router.get('/', getAllFlights);

/**
 * @swagger
 * /api/flights/search:
 *   get:
 *     summary: Search flights by route and date
 *     tags: [Flights]
 *     parameters:
 *       - in: query
 *         name: origin
 *         required: true
 *         schema:
 *           type: string
 *         description: Departure airport/city code (e.g. DEL)
 *       - in: query
 *         name: destination
 *         required: true
 *         schema:
 *           type: string
 *         description: Destination airport/city code (e.g. BOM)
 *       - in: query
 *         name: date
 *         schema:
 *           type: string
 *           format: date
 *         description: Specific departure date (YYYY-MM-DD)
 *     responses:
 *       200:
 *         description: Match search results
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Flight'
 *       400:
 *         description: Missing origin or destination query parameters
 *       500:
 *         description: Internal server error
 */
router.get('/search', searchFlights);

/**
 * @swagger
 * /api/flights/{id}:
 *   get:
 *     summary: Get flight by ID
 *     tags: [Flights]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The flight ID
 *     responses:
 *       200:
 *         description: The flight description by ID
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Flight'
 *       404:
 *         description: Flight not found
 *       500:
 *         description: Internal server error
 */
router.get('/:id', getFlightById);

/**
 * @swagger
 * /api/flights/{id}:
 *   put:
 *     summary: Update flight details
 *     tags: [Flights]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The flight ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Flight'
 *     responses:
 *       200:
 *         description: The flight was successfully updated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Flight'
 *       400:
 *         description: Bad request
 *       404:
 *         description: Flight not found
 */
router.put('/:id', updateFlight);

/**
 * @swagger
 * /api/flights/{id}:
 *   delete:
 *     summary: Delete a flight
 *     tags: [Flights]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The flight ID
 *     responses:
 *       200:
 *         description: Flight deleted successfully
 *       404:
 *         description: Flight not found
 *       500:
 *         description: Internal server error
 */
router.delete('/:id', deleteFlight);

export default router;
