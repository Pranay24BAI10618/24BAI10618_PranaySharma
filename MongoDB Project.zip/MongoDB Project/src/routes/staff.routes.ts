import { Router } from 'express';
import {
  createStaff,
  getAllStaff,
  getStaffById,
  updateStaff,
  deleteStaff
} from '../controllers/staff.controller';

const router = Router();

/**
 * @swagger
 * components:
 *   schemas:
 *     Staff:
 *       type: object
 *       required:
 *         - staffId
 *         - firstName
 *         - lastName
 *         - email
 *         - phone
 *         - role
 *         - department
 *         - salary
 *       properties:
 *         id:
 *           type: string
 *           description: The auto-generated ID of the staff member
 *         staffId:
 *           type: string
 *           description: Unique work identification code (e.g., STF-1002)
 *         firstName:
 *           type: string
 *           description: First name of the staff member
 *         lastName:
 *           type: string
 *           description: Last name of the staff member
 *         email:
 *           type: string
 *           description: Work email address (unique)
 *         phone:
 *           type: string
 *           description: Contact phone number
 *         role:
 *           type: string
 *           enum: [Pilot, Flight Attendant, Ground Staff, Security, Maintenance, Administrator]
 *           description: Job role
 *         department:
 *           type: string
 *           description: Working department (e.g., Operations, Logistics)
 *         salary:
 *           type: number
 *           description: Monthly salary
 *       example:
 *         staffId: STF-2004
 *         firstName: John
 *         lastName: Doe
 *         email: john.doe@airport.com
 *         phone: '+919999988888'
 *         role: Pilot
 *         department: Operations
 *         salary: 8500
 */

/**
 * @swagger
 * tags:
 *   name: Staff
 *   description: Staff/Employee management APIs
 */

/**
 * @swagger
 * /api/staff:
 *   post:
 *     summary: Register a new staff member
 *     tags: [Staff]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Staff'
 *     responses:
 *       201:
 *         description: Staff member successfully registered
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Staff'
 *       400:
 *         description: Staff ID or Email already exists / validation failure
 */
router.post('/', createStaff);

/**
 * @swagger
 * /api/staff:
 *   get:
 *     summary: Retrieve all registered staff members
 *     tags: [Staff]
 *     parameters:
 *       - in: query
 *         name: department
 *         schema:
 *           type: string
 *         description: Filter staff by department
 *       - in: query
 *         name: role
 *         schema:
 *           type: string
 *           enum: [Pilot, Flight Attendant, Ground Staff, Security, Maintenance, Administrator]
 *         description: Filter staff by role
 *     responses:
 *       200:
 *         description: List of staff members
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Staff'
 *       500:
 *         description: Internal server error
 */
router.get('/', getAllStaff);

/**
 * @swagger
 * /api/staff/{id}:
 *   get:
 *     summary: Get staff member by ID
 *     tags: [Staff]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The database ID of the staff member
 *     responses:
 *       200:
 *         description: Staff details by ID
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Staff'
 *       404:
 *         description: Staff member not found
 *       500:
 *         description: Internal server error
 */
router.get('/:id', getStaffById);

/**
 * @swagger
 * /api/staff/{id}:
 *   put:
 *     summary: Update staff details
 *     tags: [Staff]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The database ID of the staff member
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/Staff'
 *     responses:
 *       200:
 *         description: Staff details successfully updated
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Staff'
 *       400:
 *         description: Validation error
 *       404:
 *         description: Staff member not found
 */
router.put('/:id', updateStaff);

/**
 * @swagger
 * /api/staff/{id}:
 *   delete:
 *     summary: Remove a staff member
 *     tags: [Staff]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The database ID of the staff member
 *     responses:
 *       200:
 *         description: Staff member deleted successfully
 *       404:
 *         description: Staff member not found
 *       500:
 *         description: Internal server error
 */
router.delete('/:id', deleteStaff);

export default router;
