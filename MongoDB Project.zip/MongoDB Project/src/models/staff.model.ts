import { Schema, model, Document } from 'mongoose';

export interface IStaff extends Document {
  staffId: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  role: 'Pilot' | 'Flight Attendant' | 'Ground Staff' | 'Security' | 'Maintenance' | 'Administrator';
  department: string;
  salary: number;
}

const staffSchema = new Schema<IStaff>({
  staffId: { type: String, required: true, unique: true, uppercase: true, trim: true },
  firstName: { type: String, required: true, trim: true },
  lastName: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  phone: { type: String, required: true, trim: true },
  role: {
    type: String,
    enum: ['Pilot', 'Flight Attendant', 'Ground Staff', 'Security', 'Maintenance', 'Administrator'],
    required: true
  },
  department: { type: String, required: true, trim: true },
  salary: { type: Number, required: true, min: 0 }
}, {
  timestamps: true
});

export const Staff = model<IStaff>('Staff', staffSchema);
export default Staff;
