import { Schema, model, Document } from 'mongoose';

export interface IFlight extends Document {
  flightNumber: string;
  airline: string;
  origin: string;
  destination: string;
  departureTime: Date;
  arrivalTime: Date;
  status: 'Scheduled' | 'Delayed' | 'Boarding' | 'Departed' | 'Landed' | 'Cancelled';
  price: number;
  capacity: number;
  availableSeats: number;
  gate: string;
}

const flightSchema = new Schema<IFlight>({
  flightNumber: { type: String, required: true, unique: true, uppercase: true, trim: true },
  airline: { type: String, required: true, trim: true },
  origin: { type: String, required: true, uppercase: true, trim: true },
  destination: { type: String, required: true, uppercase: true, trim: true },
  departureTime: { type: Date, required: true },
  arrivalTime: { type: Date, required: true },
  status: {
    type: String,
    enum: ['Scheduled', 'Delayed', 'Boarding', 'Departed', 'Landed', 'Cancelled'],
    default: 'Scheduled'
  },
  price: { type: Number, required: true, min: 0 },
  capacity: { type: Number, required: true, min: 1 },
  availableSeats: { type: Number },
  gate: { type: String, default: 'Gate TBD', trim: true }
}, {
  timestamps: true
});

// Pre-save hook to initialize availableSeats to capacity
flightSchema.pre('save', function(next) {
  if (this.isNew && this.availableSeats === undefined) {
    this.availableSeats = this.capacity;
  }
  next();
});

export const Flight = model<IFlight>('Flight', flightSchema);
export default Flight;
