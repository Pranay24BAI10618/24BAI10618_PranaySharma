import { Schema, model, Document } from 'mongoose';

export interface IBooking extends Document {
  bookingReference: string;
  flight: Schema.Types.ObjectId;
  passenger: Schema.Types.ObjectId;
  seatNumber: string;
  bookingDate: Date;
  class: 'Economy' | 'Business' | 'First';
  status: 'Confirmed' | 'Cancelled';
  pricePaid: number;
}

const bookingSchema = new Schema<IBooking>({
  bookingReference: { type: String, required: true, unique: true, uppercase: true, trim: true },
  flight: { type: Schema.Types.ObjectId, ref: 'Flight', required: true },
  passenger: { type: Schema.Types.ObjectId, ref: 'Passenger', required: true },
  seatNumber: { type: String, required: true, uppercase: true, trim: true },
  bookingDate: { type: Date, default: Date.now },
  class: { type: String, enum: ['Economy', 'Business', 'First'], default: 'Economy', required: true },
  status: { type: String, enum: ['Confirmed', 'Cancelled'], default: 'Confirmed', required: true },
  pricePaid: { type: Number, required: true, min: 0 }
}, {
  timestamps: true
});

export const Booking = model<IBooking>('Booking', bookingSchema);
export default Booking;
