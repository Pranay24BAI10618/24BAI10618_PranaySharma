import { Schema, model, Document } from 'mongoose';

export interface IPassenger extends Document {
  passportNumber: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  gender: 'Male' | 'Female' | 'Other';
  dateOfBirth: Date;
}

const passengerSchema = new Schema<IPassenger>({
  passportNumber: { type: String, required: true, unique: true, uppercase: true, trim: true },
  firstName: { type: String, required: true, trim: true },
  lastName: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  phone: { type: String, required: true, trim: true },
  gender: { type: String, enum: ['Male', 'Female', 'Other'], required: true },
  dateOfBirth: { type: Date, required: true }
}, {
  timestamps: true
});

export const Passenger = model<IPassenger>('Passenger', passengerSchema);
export default Passenger;
