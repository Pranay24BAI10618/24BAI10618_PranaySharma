import readline from 'readline';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import { connectDB } from './config/db';
import Flight from './models/flight.model';
import Passenger from './models/passenger.model';
import Staff from './models/staff.model';
import Booking from './models/booking.model';

dotenv.config();

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// Helper to ask console questions synchronously
const askQuestion = (query: string): Promise<string> => {
  return new Promise((resolve) => {
    rl.question(query, (answer) => {
      resolve(answer.trim());
    });
  });
};

// Pad helper to align table cells
const padRight = (str: string, length: number): string => {
  return str.padEnd(length, ' ');
};

// Format Date to YYYY-MM-DD HH:MM
const formatDate = (date: Date | string | undefined): string => {
  if (!date) return 'TBD';
  const d = new Date(date);
  if (isNaN(d.getTime())) return 'Invalid Date';
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  const hours = String(d.getHours()).padStart(2, '0');
  const minutes = String(d.getMinutes()).padStart(2, '0');
  return `${year}-${month}-${day} ${hours}:${minutes}`;
};

// Colorizer for Flight Statuses
const getColoredStatus = (status: string): string => {
  switch (status) {
    case 'Landed':
      return `\x1b[32m${status}\x1b[0m`; // Green
    case 'Scheduled':
      return `\x1b[33m${status}\x1b[0m`; // Yellow
    case 'Cancelled':
      return `\x1b[31m${status}\x1b[0m`; // Red
    case 'Departed':
      return `\x1b[34m${status}\x1b[0m`; // Blue
    case 'Delayed':
      return `\x1b[35m${status}\x1b[0m`; // Magenta
    case 'Boarding':
      return `\x1b[36m${status}\x1b[0m`; // Cyan
    default:
      return status;
  }
};

const formatStatusColumn = (status: string, length: number): string => {
  const padded = status.padEnd(length, ' ');
  return padded.replace(status, getColoredStatus(status));
};

// ----------------------------------------------------
// TABLES DISPLAY FUNCTIONS
// ----------------------------------------------------

const printFlightsTable = (flights: any[]) => {
  console.log('\n' + '='.repeat(128));
  console.log(' '.repeat(52) + 'FLIGHT DIRECTORY');
  console.log('='.repeat(128));
  console.log(
    padRight('ID', 25) + ' | ' +
    padRight('FLIGHT', 8) + ' | ' +
    padRight('AIRLINE', 18) + ' | ' +
    padRight('FROM  -> TO', 14) + ' | ' +
    padRight('DEPARTURE', 17) + ' | ' +
    padRight('ARRIVAL', 17) + ' | ' +
    padRight('STATUS', 11) + ' | ' +
    padRight('GATE', 10)
  );
  console.log('-'.repeat(25) + '+' + '-'.repeat(10) + '+' + '-'.repeat(20) + '+' + '-'.repeat(16) + '+' + '-'.repeat(19) + '+' + '-'.repeat(19) + '+' + '-'.repeat(13) + '+' + '-'.repeat(12));
  
  if (flights.length === 0) {
    console.log(' '.repeat(50) + 'No flights found in database.');
  } else {
    flights.forEach(f => {
      const fromTo = `${f.origin}   -> ${f.destination}`;
      const statusCol = formatStatusColumn(f.status || 'Scheduled', 11);
      console.log(
        padRight(String(f._id), 25) + ' | ' +
        padRight(f.flightNumber || '', 8) + ' | ' +
        padRight(f.airline || '', 18) + ' | ' +
        padRight(fromTo, 14) + ' | ' +
        padRight(formatDate(f.departureTime), 17) + ' | ' +
        padRight(formatDate(f.arrivalTime), 17) + ' | ' +
        statusCol + ' | ' +
        padRight(f.gate || 'Gate TBD', 10)
      );
    });
  }
  console.log('='.repeat(128) + '\n');
};

const printPassengersTable = (passengers: any[]) => {
  console.log('\n' + '='.repeat(120));
  console.log(' '.repeat(50) + 'PASSENGER DIRECTORY');
  console.log('='.repeat(120));
  console.log(
    padRight('ID', 25) + ' | ' +
    padRight('PASSPORT', 10) + ' | ' +
    padRight('FULL NAME', 22) + ' | ' +
    padRight('GENDER', 8) + ' | ' +
    padRight('PHONE', 15) + ' | ' +
    padRight('EMAIL', 28)
  );
  console.log('-'.repeat(25) + '+' + '-'.repeat(12) + '+' + '-'.repeat(24) + '+' + '-'.repeat(10) + '+' + '-'.repeat(17) + '+' + '-'.repeat(30));
  
  if (passengers.length === 0) {
    console.log(' '.repeat(48) + 'No registered passengers found.');
  } else {
    passengers.forEach(p => {
      const name = `${p.firstName} ${p.lastName}`;
      console.log(
        padRight(String(p._id), 25) + ' | ' +
        padRight(p.passportNumber || '', 10) + ' | ' +
        padRight(name, 22) + ' | ' +
        padRight(p.gender || '', 8) + ' | ' +
        padRight(p.phone || '', 15) + ' | ' +
        padRight(p.email || '', 28)
      );
    });
  }
  console.log('='.repeat(120) + '\n');
};

const printStaffTable = (staff: any[]) => {
  console.log('\n' + '='.repeat(120));
  console.log(' '.repeat(52) + 'STAFF DIRECTORY');
  console.log('='.repeat(120));
  console.log(
    padRight('ID', 25) + ' | ' +
    padRight('STAFF ID', 10) + ' | ' +
    padRight('FULL NAME', 22) + ' | ' +
    padRight('ROLE', 16) + ' | ' +
    padRight('DEPARTMENT', 18) + ' | ' +
    padRight('SALARY ($)', 10)
  );
  console.log('-'.repeat(25) + '+' + '-'.repeat(12) + '+' + '-'.repeat(24) + '+' + '-'.repeat(18) + '+' + '-'.repeat(20) + '+' + '-'.repeat(12));
  
  if (staff.length === 0) {
    console.log(' '.repeat(48) + 'No staff members registered.');
  } else {
    staff.forEach(s => {
      const name = `${s.firstName} ${s.lastName}`;
      console.log(
        padRight(String(s._id), 25) + ' | ' +
        padRight(s.staffId || '', 10) + ' | ' +
        padRight(name, 22) + ' | ' +
        padRight(s.role || '', 16) + ' | ' +
        padRight(s.department || '', 18) + ' | ' +
        padRight(String(s.salary || 0), 10)
      );
    });
  }
  console.log('='.repeat(120) + '\n');
};

const printBookingsTable = (bookings: any[]) => {
  console.log('\n' + '='.repeat(128));
  console.log(' '.repeat(52) + 'BOOKINGS DIRECTORY');
  console.log('='.repeat(128));
  console.log(
    padRight('ID', 25) + ' | ' +
    padRight('REF CODE', 10) + ' | ' +
    padRight('PASSENGER NAME', 22) + ' | ' +
    padRight('FLIGHT', 8) + ' | ' +
    padRight('SEAT', 6) + ' | ' +
    padRight('CLASS', 10) + ' | ' +
    padRight('STATUS', 11) + ' | ' +
    padRight('PAID ($)', 10)
  );
  console.log('-'.repeat(25) + '+' + '-'.repeat(12) + '+' + '-'.repeat(24) + '+' + '-'.repeat(10) + '+' + '-'.repeat(8) + '+' + '-'.repeat(12) + '+' + '-'.repeat(13) + '+' + '-'.repeat(12));
  
  if (bookings.length === 0) {
    console.log(' '.repeat(50) + 'No bookings found.');
  } else {
    bookings.forEach(b => {
      const passengerName = b.passenger ? `${b.passenger.firstName} ${b.passenger.lastName}` : 'N/A';
      const flightNum = b.flight ? b.flight.flightNumber : 'N/A';
      const statusCol = b.status === 'Cancelled' ? `\x1b[31m${b.status}\x1b[0m` : `\x1b[32m${b.status}\x1b[0m`;
      const paddedStatus = b.status.padEnd(11, ' ').replace(b.status, statusCol);
      console.log(
        padRight(String(b._id), 25) + ' | ' +
        padRight(b.bookingReference || '', 10) + ' | ' +
        padRight(passengerName, 22) + ' | ' +
        padRight(flightNum, 8) + ' | ' +
        padRight(b.seatNumber || '', 6) + ' | ' +
        padRight(b.class || '', 10) + ' | ' +
        paddedStatus + ' | ' +
        padRight(String(b.pricePaid || 0), 10)
      );
    });
  }
  console.log('='.repeat(128) + '\n');
};

// ----------------------------------------------------
// SUB-MENU ROUTINES
// ----------------------------------------------------

// 1. Flights Operations
const addFlightPrompt = async () => {
  console.log('\n--- ADD NEW FLIGHT ---');
  const flightNumber = await askQuestion('Flight Number (e.g. AI-101): ');
  const airline = await askQuestion('Airline: ');
  const origin = await askQuestion('Origin (e.g. DEL): ');
  const destination = await askQuestion('Destination (e.g. BOM): ');
  const depTimeStr = await askQuestion('Departure Time (YYYY-MM-DD HH:MM): ');
  const arrTimeStr = await askQuestion('Arrival Time (YYYY-MM-DD HH:MM): ');
  const price = parseFloat(await askQuestion('Ticket Price ($): '));
  const capacity = parseInt(await askQuestion('Capacity (number of seats): '), 10);
  const gate = await askQuestion('Gate (e.g. Gate A12): ');

  if (!flightNumber || !airline || !origin || !destination || !depTimeStr || !arrTimeStr || isNaN(price) || isNaN(capacity)) {
    console.log('\x1b[31mError: Invalid input. All fields are required and numbers must be valid.\x1b[0m');
    return;
  }

  try {
    const flight = new Flight({
      flightNumber,
      airline,
      origin,
      destination,
      departureTime: new Date(depTimeStr),
      arrivalTime: new Date(arrTimeStr),
      price,
      capacity,
      availableSeats: capacity,
      gate: gate || 'Gate TBD'
    });
    await flight.save();
    console.log('\x1b[32mFlight created successfully!\x1b[0m');
  } catch (error: any) {
    console.log('\x1b[31mError saving flight:\x1b[0m', error.message);
  }
};

const listFlightsPrompt = async () => {
  const flights = await Flight.find({});
  printFlightsTable(flights);
};

const searchFlightsPrompt = async () => {
  console.log('\n--- SEARCH FLIGHTS ---');
  const origin = await askQuestion('Origin (e.g. DEL): ');
  const destination = await askQuestion('Destination (e.g. BOM): ');

  if (!origin || !destination) {
    console.log('\x1b[31mError: Origin and Destination are required.\x1b[0m');
    return;
  }

  const flights = await Flight.find({
    origin: { $regex: origin, $options: 'i' },
    destination: { $regex: destination, $options: 'i' }
  });
  printFlightsTable(flights);
};

const updateFlightStatusPrompt = async () => {
  console.log('\n--- UPDATE FLIGHT STATUS ---');
  const flights = await Flight.find({}, '_id flightNumber origin destination status');
  if (flights.length === 0) {
    console.log('No flights available to update.');
    return;
  }
  
  flights.forEach(f => {
    console.log(`ID: ${f._id} | Flight: ${f.flightNumber} (${f.origin} -> ${f.destination}) | Status: ${f.status}`);
  });

  const flightId = await askQuestion('\nEnter Flight ID to update: ');
  if (!mongoose.Types.ObjectId.isValid(flightId)) {
    console.log('\x1b[31mInvalid MongoDB ID.\x1b[0m');
    return;
  }

  console.log('\nSelect New Status:');
  console.log('1. Scheduled');
  console.log('2. Delayed');
  console.log('3. Boarding');
  console.log('4. Departed');
  console.log('5. Landed');
  console.log('6. Cancelled');
  
  const statusChoice = await askQuestion('Choice (1-6): ');
  let status = '';
  switch (statusChoice) {
    case '1': status = 'Scheduled'; break;
    case '2': status = 'Delayed'; break;
    case '3': status = 'Boarding'; break;
    case '4': status = 'Departed'; break;
    case '5': status = 'Landed'; break;
    case '6': status = 'Cancelled'; break;
    default:
      console.log('\x1b[31mInvalid selection.\x1b[0m');
      return;
  }

  const gateOption = await askQuestion('Update Gate? (Leave blank to keep same): ');

  try {
    const updateObj: any = { status };
    if (gateOption.trim()) {
      updateObj.gate = gateOption.trim();
    }
    const flight = await Flight.findByIdAndUpdate(flightId, updateObj, { new: true });
    if (!flight) {
      console.log('\x1b[31mFlight not found.\x1b[0m');
      return;
    }
    console.log('\x1b[32mFlight status updated successfully to:\x1b[0m', flight.status);
  } catch (error: any) {
    console.log('\x1b[31mError updating flight:\x1b[0m', error.message);
  }
};

const deleteFlightPrompt = async () => {
  console.log('\n--- DELETE FLIGHT ---');
  const flightId = await askQuestion('Enter Flight ID to delete: ');
  if (!mongoose.Types.ObjectId.isValid(flightId)) {
    console.log('\x1b[31mInvalid ID.\x1b[0m');
    return;
  }

  try {
    const res = await Flight.findByIdAndDelete(flightId);
    if (!res) {
      console.log('\x1b[31mFlight not found.\x1b[0m');
      return;
    }
    console.log('\x1b[32mFlight deleted successfully!\x1b[0m');
  } catch (error: any) {
    console.log('\x1b[31mError deleting flight:\x1b[0m', error.message);
  }
};

const flightsMenu = async () => {
  let inMenu = true;
  while (inMenu) {
    console.log('\n' + '='.repeat(60));
    console.log(' '.repeat(20) + 'FLIGHTS MANAGEMENT');
    console.log('='.repeat(60));
    console.log('1. Add New Flight');
    console.log('2. List All Flights');
    console.log('3. Search Flights by Route');
    console.log('4. Update Flight Status');
    console.log('5. Delete Flight');
    console.log('6. Return to Main Menu');
    console.log('='.repeat(60));
    
    const choice = await askQuestion('Enter choice (1-6): ');
    switch (choice) {
      case '1': await addFlightPrompt(); break;
      case '2': await listFlightsPrompt(); break;
      case '3': await searchFlightsPrompt(); break;
      case '4': await updateFlightStatusPrompt(); break;
      case '5': await deleteFlightPrompt(); break;
      case '6': inMenu = false; break;
      default:
        console.log('Invalid choice. Please enter a number between 1 and 6.');
    }
  }
};


// 2. Passengers Operations
const addPassengerPrompt = async () => {
  console.log('\n--- REGISTER NEW PASSENGER ---');
  const passportNumber = await askQuestion('Passport Number (e.g. Z1234567): ');
  const firstName = await askQuestion('First Name: ');
  const lastName = await askQuestion('Last Name: ');
  const email = await askQuestion('Email: ');
  const phone = await askQuestion('Phone: ');
  console.log('Select Gender: (1. Male, 2. Female, 3. Other)');
  const genderChoice = await askQuestion('Choice (1-3): ');
  let gender: 'Male' | 'Female' | 'Other' = 'Male';
  if (genderChoice === '2') gender = 'Female';
  if (genderChoice === '3') gender = 'Other';

  const dobStr = await askQuestion('Date of Birth (YYYY-MM-DD): ');

  if (!passportNumber || !firstName || !lastName || !email || !phone || !dobStr) {
    console.log('\x1b[31mError: All fields are required.\x1b[0m');
    return;
  }

  try {
    const passenger = new Passenger({
      passportNumber,
      firstName,
      lastName,
      email,
      phone,
      gender,
      dateOfBirth: new Date(dobStr)
    });
    await passenger.save();
    console.log('\x1b[32mPassenger registered successfully!\x1b[0m');
  } catch (error: any) {
    console.log('\x1b[31mError registering passenger:\x1b[0m', error.message);
  }
};

const listPassengersPrompt = async () => {
  const passengers = await Passenger.find({});
  printPassengersTable(passengers);
};

const deletePassengerPrompt = async () => {
  console.log('\n--- REMOVE PASSENGER ---');
  const id = await askQuestion('Enter Passenger ID to remove: ');
  if (!mongoose.Types.ObjectId.isValid(id)) {
    console.log('\x1b[31mInvalid ID.\x1b[0m');
    return;
  }

  try {
    const res = await Passenger.findByIdAndDelete(id);
    if (!res) {
      console.log('\x1b[31mPassenger not found.\x1b[0m');
      return;
    }
    console.log('\x1b[32mPassenger deleted successfully!\x1b[0m');
  } catch (error: any) {
    console.log('\x1b[31mError deleting passenger:\x1b[0m', error.message);
  }
};

const passengersMenu = async () => {
  let inMenu = true;
  while (inMenu) {
    console.log('\n' + '='.repeat(60));
    console.log(' '.repeat(19) + 'PASSENGERS MANAGEMENT');
    console.log('='.repeat(60));
    console.log('1. Register New Passenger');
    console.log('2. List All Passengers');
    console.log('3. Remove Passenger');
    console.log('4. Return to Main Menu');
    console.log('='.repeat(60));
    
    const choice = await askQuestion('Enter choice (1-4): ');
    switch (choice) {
      case '1': await addPassengerPrompt(); break;
      case '2': await listPassengersPrompt(); break;
      case '3': await deletePassengerPrompt(); break;
      case '4': inMenu = false; break;
      default:
        console.log('Invalid choice. Please enter a number between 1 and 4.');
    }
  }
};


// 3. Staff Operations
const addStaffPrompt = async () => {
  console.log('\n--- REGISTER NEW STAFF MEMBER ---');
  const staffId = await askQuestion('Staff ID (e.g. STF-2004): ');
  const firstName = await askQuestion('First Name: ');
  const lastName = await askQuestion('Last Name: ');
  const email = await askQuestion('Email: ');
  const phone = await askQuestion('Phone: ');
  console.log('Select Role:');
  console.log('1. Pilot  2. Flight Attendant  3. Ground Staff  4. Security  5. Maintenance  6. Administrator');
  const roleChoice = await askQuestion('Choice (1-6): ');
  let role = 'Ground Staff';
  if (roleChoice === '1') role = 'Pilot';
  else if (roleChoice === '2') role = 'Flight Attendant';
  else if (roleChoice === '4') role = 'Security';
  else if (roleChoice === '5') role = 'Maintenance';
  else if (roleChoice === '6') role = 'Administrator';

  const department = await askQuestion('Department (e.g. Operations): ');
  const salary = parseFloat(await askQuestion('Salary ($): '));

  if (!staffId || !firstName || !lastName || !email || !phone || !department || isNaN(salary)) {
    console.log('\x1b[31mError: All fields are required and salary must be a number.\x1b[0m');
    return;
  }

  try {
    const s = new Staff({
      staffId,
      firstName,
      lastName,
      email,
      phone,
      role,
      department,
      salary
    });
    await s.save();
    console.log('\x1b[32mStaff member registered successfully!\x1b[0m');
  } catch (error: any) {
    console.log('\x1b[31mError registering staff:\x1b[0m', error.message);
  }
};

const listStaffPrompt = async () => {
  const staff = await Staff.find({});
  printStaffTable(staff);
};

const deleteStaffPrompt = async () => {
  console.log('\n--- REMOVE STAFF MEMBER ---');
  const id = await askQuestion('Enter Staff database ID to remove: ');
  if (!mongoose.Types.ObjectId.isValid(id)) {
    console.log('\x1b[31mInvalid ID.\x1b[0m');
    return;
  }

  try {
    const res = await Staff.findByIdAndDelete(id);
    if (!res) {
      console.log('\x1b[31mStaff member not found.\x1b[0m');
      return;
    }
    console.log('\x1b[32mStaff record deleted successfully!\x1b[0m');
  } catch (error: any) {
    console.log('\x1b[31mError deleting staff:\x1b[0m', error.message);
  }
};

const staffMenu = async () => {
  let inMenu = true;
  while (inMenu) {
    console.log('\n' + '='.repeat(60));
    console.log(' '.repeat(21) + 'STAFF MANAGEMENT');
    console.log('='.repeat(60));
    console.log('1. Register New Staff Member');
    console.log('2. List All Staff');
    console.log('3. Remove Staff Member');
    console.log('4. Return to Main Menu');
    console.log('='.repeat(60));
    
    const choice = await askQuestion('Enter choice (1-4): ');
    switch (choice) {
      case '1': await addStaffPrompt(); break;
      case '2': await listStaffPrompt(); break;
      case '3': await deleteStaffPrompt(); break;
      case '4': inMenu = false; break;
      default:
        console.log('Invalid choice. Please enter a number between 1 and 4.');
    }
  }
};


// 4. Booking Operations
const bookFlightPrompt = async () => {
  console.log('\n--- BOOK A FLIGHT ---');
  const flightId = await askQuestion('Enter Flight database ID: ');
  const passengerId = await askQuestion('Enter Passenger database ID: ');
  const seatNumber = await askQuestion('Designated Seat (e.g. 12A): ');
  
  console.log('Select Class: (1. Economy, 2. Business, 3. First)');
  const classChoice = await askQuestion('Choice (1-3): ');
  let bookingClass = 'Economy';
  if (classChoice === '2') bookingClass = 'Business';
  if (classChoice === '3') bookingClass = 'First';

  if (!flightId || !passengerId || !seatNumber) {
    console.log('\x1b[31mError: Flight ID, Passenger ID, and Seat are required.\x1b[0m');
    return;
  }

  if (!mongoose.Types.ObjectId.isValid(flightId) || !mongoose.Types.ObjectId.isValid(passengerId)) {
    console.log('\x1b[31mError: Invalid Flight or Passenger ID format.\x1b[0m');
    return;
  }

  try {
    // Verify passenger
    const passenger = await Passenger.findById(passengerId);
    if (!passenger) {
      console.log('\x1b[31mError: Passenger not found.\x1b[0m');
      return;
    }

    // Atomically decrement seats to avoid race conditions
    const flight = await Flight.findOneAndUpdate(
      { _id: flightId, availableSeats: { $gt: 0 } },
      { $inc: { availableSeats: -1 } },
      { new: true }
    );

    if (!flight) {
      console.log('\x1b[31mError: Flight not found or no seats available.\x1b[0m');
      return;
    }

    // Generate unique booking code
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let bookingReference = 'BK-';
    for (let i = 0; i < 6; i++) {
      bookingReference += chars.charAt(Math.floor(Math.random() * chars.length));
    }

    const booking = new Booking({
      bookingReference,
      flight: flightId,
      passenger: passengerId,
      seatNumber,
      class: bookingClass,
      pricePaid: flight.price,
      status: 'Confirmed'
    });

    await booking.save();
    console.log(`\x1b[32mTicket booked successfully! Reference Code: ${bookingReference}\x1b[0m`);
  } catch (error: any) {
    console.log('\x1b[31mError reserving ticket:\x1b[0m', error.message);
  }
};

const listBookingsPrompt = async () => {
  const bookings = await Booking.find({}).populate('flight').populate('passenger');
  printBookingsTable(bookings);
};

const cancelBookingPrompt = async () => {
  console.log('\n--- CANCEL BOOKING ---');
  const bookingId = await askQuestion('Enter Booking ID to cancel: ');
  if (!mongoose.Types.ObjectId.isValid(bookingId)) {
    console.log('\x1b[31mInvalid ID.\x1b[0m');
    return;
  }

  try {
    const booking = await Booking.findById(bookingId);
    if (!booking) {
      console.log('\x1b[31mBooking not found.\x1b[0m');
      return;
    }

    if (booking.status === 'Cancelled') {
      console.log('\x1b[31mBooking is already cancelled.\x1b[0m');
      return;
    }

    booking.status = 'Cancelled';
    await booking.save();

    // Increment seats back on Flight
    await Flight.findByIdAndUpdate(booking.flight, { $inc: { availableSeats: 1 } });
    console.log('\x1b[32mBooking cancelled successfully and seat restored.\x1b[0m');
  } catch (error: any) {
    console.log('\x1b[31mError cancelling booking:\x1b[0m', error.message);
  }
};

const deleteBookingPrompt = async () => {
  console.log('\n--- DELETE BOOKING RECORD ---');
  const bookingId = await askQuestion('Enter Booking ID to delete: ');
  if (!mongoose.Types.ObjectId.isValid(bookingId)) {
    console.log('\x1b[31mInvalid ID.\x1b[0m');
    return;
  }

  try {
    const booking = await Booking.findById(bookingId);
    if (!booking) {
      console.log('\x1b[31mBooking not found.\x1b[0m');
      return;
    }

    // If active, restore the seat first
    if (booking.status === 'Confirmed') {
      await Flight.findByIdAndUpdate(booking.flight, { $inc: { availableSeats: 1 } });
    }

    await Booking.findByIdAndDelete(bookingId);
    console.log('\x1b[32mBooking record permanently deleted from database.\x1b[0m');
  } catch (error: any) {
    console.log('\x1b[31mError deleting booking:\x1b[0m', error.message);
  }
};

const bookingsMenu = async () => {
  let inMenu = true;
  while (inMenu) {
    console.log('\n' + '='.repeat(60));
    console.log(' '.repeat(20) + 'BOOKINGS MANAGEMENT');
    console.log('='.repeat(60));
    console.log('1. Book Flight (Reserve Ticket)');
    console.log('2. List All Bookings');
    console.log('3. Cancel Flight Booking');
    console.log('4. Delete Booking Record');
    console.log('5. Return to Main Menu');
    console.log('='.repeat(60));
    
    const choice = await askQuestion('Enter choice (1-5): ');
    switch (choice) {
      case '1': await bookFlightPrompt(); break;
      case '2': await listBookingsPrompt(); break;
      case '3': await cancelBookingPrompt(); break;
      case '4': await deleteBookingPrompt(); break;
      case '5': inMenu = false; break;
      default:
        console.log('Invalid choice. Please enter a number between 1 and 5.');
    }
  }
};

// ----------------------------------------------------
// MAIN ROUTINE
// ----------------------------------------------------

const startCLI = async () => {
  // Connect to Database
  await connectDB();
  
  let running = true;
  while (running) {
    console.log('\n' + '='.repeat(60));
    console.log(' '.repeat(5) + 'AIRPORT SERVICES MANAGEMENT SYSTEM (CLI CONSOLE)');
    console.log('='.repeat(60));
    console.log(`Developer: Pranay Sharma (24BAI10618) - VIT Bhopal`);
    console.log('='.repeat(60));
    console.log('1. Flights Directory Management');
    console.log('2. Passengers Directory Management');
    console.log('3. Staff Directory Management');
    console.log('4. Bookings & Ticket Reservations');
    console.log('5. Exit');
    console.log('='.repeat(60));
    
    const choice = await askQuestion('Enter choice (1-5): ');
    switch (choice) {
      case '1': await flightsMenu(); break;
      case '2': await passengersMenu(); break;
      case '3': await staffMenu(); break;
      case '4': await bookingsMenu(); break;
      case '5':
        console.log('Exiting program. Goodbye!');
        running = false;
        rl.close();
        await mongoose.connection.close();
        process.exit(0);
      default:
        console.log('\x1b[31mInvalid choice. Please choose between 1 and 5.\x1b[0m');
    }
  }
};

startCLI();
