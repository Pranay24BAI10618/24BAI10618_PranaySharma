import { Request, Response } from 'express';
import Booking from '../models/booking.model';
import Flight from '../models/flight.model';
import Passenger from '../models/passenger.model';

// Helper to generate a unique booking reference
const generateBookingReference = (): string => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let ref = 'BK-';
  for (let i = 0; i < 6; i++) {
    ref += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return ref;
};

// Create a new booking
export const createBooking = async (req: Request, res: Response): Promise<void> => {
  try {
    const { flightId, passengerId, seatNumber, class: bookingClass, pricePaid } = req.body;

    if (!flightId || !passengerId || !seatNumber) {
      res.status(400).json({ message: 'flightId, passengerId, and seatNumber are required' });
      return;
    }

    // 1. Verify passenger exists
    const passengerExists = await Passenger.findById(passengerId);
    if (!passengerExists) {
      res.status(404).json({ message: 'Passenger not found' });
      return;
    }

    // 2. Fetch flight
    const flight = await Flight.findById(flightId);
    if (!flight) {
      res.status(404).json({ message: 'Flight not found' });
      return;
    }

    // 3. Atomically decrement seats to avoid race conditions (double-booking)
    const updatedFlight = await Flight.findOneAndUpdate(
      { _id: flightId, availableSeats: { $gt: 0 } },
      { $inc: { availableSeats: -1 } },
      { new: true }
    );

    if (!updatedFlight) {
      res.status(400).json({ message: 'No available seats on this flight' });
      return;
    }

    // 4. Generate booking
    const bookingRef = generateBookingReference();
    const finalPrice = pricePaid !== undefined ? pricePaid : flight.price;

    const newBooking = new Booking({
      bookingReference: bookingRef,
      flight: flightId,
      passenger: passengerId,
      seatNumber,
      class: bookingClass || 'Economy',
      pricePaid: finalPrice,
      status: 'Confirmed'
    });

    const savedBooking = await newBooking.save();

    // Populate and return
    const populatedBooking = await Booking.findById(savedBooking._id)
      .populate('flight')
      .populate('passenger');

    res.status(201).json(populatedBooking);
  } catch (error: any) {
    res.status(400).json({ message: 'Error creating booking', error: error.message });
  }
};

// Cancel a booking
export const cancelBooking = async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;

    const booking = await Booking.findById(id);
    if (!booking) {
      res.status(404).json({ message: 'Booking not found' });
      return;
    }

    if (booking.status === 'Cancelled') {
      res.status(400).json({ message: 'Booking is already cancelled' });
      return;
    }

    // 1. Update booking status
    booking.status = 'Cancelled';
    await booking.save();

    // 2. Increment available seats on the flight
    await Flight.findByIdAndUpdate(booking.flight, { $inc: { availableSeats: 1 } });

    const populatedBooking = await Booking.findById(id)
      .populate('flight')
      .populate('passenger');

    res.status(200).json({ message: 'Booking cancelled successfully', booking: populatedBooking });
  } catch (error: any) {
    res.status(400).json({ message: 'Error cancelling booking', error: error.message });
  }
};

// Get all bookings (with optional population and filters)
export const getAllBookings = async (req: Request, res: Response): Promise<void> => {
  try {
    const { passengerId, flightId, status } = req.query;
    const filter: any = {};

    if (passengerId) filter.passenger = passengerId;
    if (flightId) filter.flight = flightId;
    if (status) filter.status = status;

    const bookings = await Booking.find(filter)
      .populate('flight')
      .populate('passenger');

    res.status(200).json(bookings);
  } catch (error: any) {
    res.status(500).json({ message: 'Error retrieving bookings', error: error.message });
  }
};

// Get booking by ID
export const getBookingById = async (req: Request, res: Response): Promise<void> => {
  try {
    const booking = await Booking.findById(req.params.id)
      .populate('flight')
      .populate('passenger');

    if (!booking) {
      res.status(404).json({ message: 'Booking not found' });
      return;
    }
    res.status(200).json(booking);
  } catch (error: any) {
    res.status(500).json({ message: 'Error retrieving booking', error: error.message });
  }
};

// Delete booking (Clean up database entry)
export const deleteBooking = async (req: Request, res: Response): Promise<void> => {
  try {
    const booking = await Booking.findById(req.params.id);
    if (!booking) {
      res.status(404).json({ message: 'Booking not found' });
      return;
    }

    // If deleting a Confirmed booking, restore the seat first
    if (booking.status === 'Confirmed') {
      await Flight.findByIdAndUpdate(booking.flight, { $inc: { availableSeats: 1 } });
    }

    await Booking.findByIdAndDelete(req.params.id);
    res.status(200).json({ message: 'Booking deleted and seat restored (if active)' });
  } catch (error: any) {
    res.status(500).json({ message: 'Error deleting booking', error: error.message });
  }
};
