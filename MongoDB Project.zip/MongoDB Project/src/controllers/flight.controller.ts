import { Request, Response } from 'express';
import Flight from '../models/flight.model';

// Create a new flight
export const createFlight = async (req: Request, res: Response): Promise<void> => {
  try {
    const flightData = req.body;
    
    // Explicitly set availableSeats to capacity if not provided
    if (flightData.availableSeats === undefined) {
      flightData.availableSeats = flightData.capacity;
    }

    const newFlight = new Flight(flightData);
    const savedFlight = await newFlight.save();
    res.status(201).json(savedFlight);
  } catch (error: any) {
    res.status(400).json({ message: 'Error creating flight', error: error.message });
  }
};

// Get all flights (with optional filter for origin/destination/status)
export const getAllFlights = async (req: Request, res: Response): Promise<void> => {
  try {
    const { origin, destination, status } = req.query;
    const filter: any = {};

    if (origin) filter.origin = { $regex: String(origin), $options: 'i' };
    if (destination) filter.destination = { $regex: String(destination), $options: 'i' };
    if (status) filter.status = String(status);

    const flights = await Flight.find(filter);
    res.status(200).json(flights);
  } catch (error: any) {
    res.status(500).json({ message: 'Error retrieving flights', error: error.message });
  }
};

// Get flight by ID
export const getFlightById = async (req: Request, res: Response): Promise<void> => {
  try {
    const flight = await Flight.findById(req.params.id);
    if (!flight) {
      res.status(404).json({ message: 'Flight not found' });
      return;
    }
    res.status(200).json(flight);
  } catch (error: any) {
    res.status(500).json({ message: 'Error retrieving flight', error: error.message });
  }
};

// Update flight details
export const updateFlight = async (req: Request, res: Response): Promise<void> => {
  try {
    const flight = await Flight.findById(req.params.id);
    if (!flight) {
      res.status(404).json({ message: 'Flight not found' });
      return;
    }

    // If capacity is being updated, we should adjust availableSeats accordingly
    if (req.body.capacity !== undefined) {
      const capacityDiff = req.body.capacity - flight.capacity;
      req.body.availableSeats = flight.availableSeats + capacityDiff;
      if (req.body.availableSeats < 0) {
        res.status(400).json({ message: 'Cannot reduce capacity below the number of booked seats' });
        return;
      }
    }

    const updatedFlight = await Flight.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    res.status(200).json(updatedFlight);
  } catch (error: any) {
    res.status(400).json({ message: 'Error updating flight', error: error.message });
  }
};

// Delete flight
export const deleteFlight = async (req: Request, res: Response): Promise<void> => {
  try {
    const deletedFlight = await Flight.findByIdAndDelete(req.params.id);
    if (!deletedFlight) {
      res.status(404).json({ message: 'Flight not found' });
      return;
    }
    res.status(200).json({ message: 'Flight deleted successfully' });
  } catch (error: any) {
    res.status(500).json({ message: 'Error deleting flight', error: error.message });
  }
};

// Search flights by route and date
export const searchFlights = async (req: Request, res: Response): Promise<void> => {
  try {
    const { origin, destination, date } = req.query;
    
    if (!origin || !destination) {
      res.status(400).json({ message: 'Origin and Destination are required query parameters' });
      return;
    }

    const query: any = {
      origin: { $regex: String(origin), $options: 'i' },
      destination: { $regex: String(destination), $options: 'i' }
    };

    if (date) {
      const searchDate = new Date(String(date));
      // Start of day
      const startOfDay = new Date(searchDate.setHours(0, 0, 0, 0));
      // End of day
      const endOfDay = new Date(searchDate.setHours(23, 59, 59, 999));
      
      query.departureTime = {
        $gte: startOfDay,
        $lte: endOfDay
      };
    }

    const flights = await Flight.find(query);
    res.status(200).json(flights);
  } catch (error: any) {
    res.status(500).json({ message: 'Error searching flights', error: error.message });
  }
};
