import { Request, Response } from 'express';
import Passenger from '../models/passenger.model';

// Create a new passenger
export const createPassenger = async (req: Request, res: Response): Promise<void> => {
  try {
    const newPassenger = new Passenger(req.body);
    const savedPassenger = await newPassenger.save();
    res.status(201).json(savedPassenger);
  } catch (error: any) {
    res.status(400).json({ message: 'Error creating passenger', error: error.message });
  }
};

// Get all passengers
export const getAllPassengers = async (req: Request, res: Response): Promise<void> => {
  try {
    const { passportNumber, email } = req.query;
    const filter: any = {};

    if (passportNumber) filter.passportNumber = { $regex: String(passportNumber), $options: 'i' };
    if (email) filter.email = { $regex: String(email), $options: 'i' };

    const passengers = await Passenger.find(filter);
    res.status(200).json(passengers);
  } catch (error: any) {
    res.status(500).json({ message: 'Error retrieving passengers', error: error.message });
  }
};

// Get passenger by ID
export const getPassengerById = async (req: Request, res: Response): Promise<void> => {
  try {
    const passenger = await Passenger.findById(req.params.id);
    if (!passenger) {
      res.status(404).json({ message: 'Passenger not found' });
      return;
    }
    res.status(200).json(passenger);
  } catch (error: any) {
    res.status(500).json({ message: 'Error retrieving passenger', error: error.message });
  }
};

// Update passenger
export const updatePassenger = async (req: Request, res: Response): Promise<void> => {
  try {
    const updatedPassenger = await Passenger.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    if (!updatedPassenger) {
      res.status(404).json({ message: 'Passenger not found' });
      return;
    }
    res.status(200).json(updatedPassenger);
  } catch (error: any) {
    res.status(400).json({ message: 'Error updating passenger', error: error.message });
  }
};

// Delete passenger
export const deletePassenger = async (req: Request, res: Response): Promise<void> => {
  try {
    const deletedPassenger = await Passenger.findByIdAndDelete(req.params.id);
    if (!deletedPassenger) {
      res.status(404).json({ message: 'Passenger not found' });
      return;
    }
    res.status(200).json({ message: 'Passenger deleted successfully' });
  } catch (error: any) {
    res.status(500).json({ message: 'Error deleting passenger', error: error.message });
  }
};
