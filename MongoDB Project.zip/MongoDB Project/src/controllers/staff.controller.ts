import { Request, Response } from 'express';
import Staff from '../models/staff.model';

// Create a new staff member
export const createStaff = async (req: Request, res: Response): Promise<void> => {
  try {
    const newStaff = new Staff(req.body);
    const savedStaff = await newStaff.save();
    res.status(201).json(savedStaff);
  } catch (error: any) {
    res.status(400).json({ message: 'Error creating staff member', error: error.message });
  }
};

// Get all staff members (with optional filter for department or role)
export const getAllStaff = async (req: Request, res: Response): Promise<void> => {
  try {
    const { department, role } = req.query;
    const filter: any = {};

    if (department) filter.department = { $regex: String(department), $options: 'i' };
    if (role) filter.role = String(role);

    const staffMembers = await Staff.find(filter);
    res.status(200).json(staffMembers);
  } catch (error: any) {
    res.status(500).json({ message: 'Error retrieving staff members', error: error.message });
  }
};

// Get staff member by ID
export const getStaffById = async (req: Request, res: Response): Promise<void> => {
  try {
    const staffMember = await Staff.findById(req.params.id);
    if (!staffMember) {
      res.status(404).json({ message: 'Staff member not found' });
      return;
    }
    res.status(200).json(staffMember);
  } catch (error: any) {
    res.status(500).json({ message: 'Error retrieving staff member', error: error.message });
  }
};

// Update staff member
export const updateStaff = async (req: Request, res: Response): Promise<void> => {
  try {
    const updatedStaff = await Staff.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    if (!updatedStaff) {
      res.status(404).json({ message: 'Staff member not found' });
      return;
    }
    res.status(200).json(updatedStaff);
  } catch (error: any) {
    res.status(400).json({ message: 'Error updating staff member', error: error.message });
  }
};

// Delete staff member
export const deleteStaff = async (req: Request, res: Response): Promise<void> => {
  try {
    const deletedStaff = await Staff.findByIdAndDelete(req.params.id);
    if (!deletedStaff) {
      res.status(404).json({ message: 'Staff member not found' });
      return;
    }
    res.status(200).json({ message: 'Staff member deleted successfully' });
  } catch (error: any) {
    res.status(500).json({ message: 'Error deleting staff member', error: error.message });
  }
};
